extern int user_abort;
extern void signals_init(void);
extern void signals_block(void);
extern void signals_unblock(void);
extern void signals_exit(void);
