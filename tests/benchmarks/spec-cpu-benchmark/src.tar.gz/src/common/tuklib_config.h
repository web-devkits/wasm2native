#ifdef HAVE_CONFIG_H
#	include "sysdefs.h"
#else
#	include <stddef.h>
#	include <inttypes.h>
#	include <limits.h>
#endif
