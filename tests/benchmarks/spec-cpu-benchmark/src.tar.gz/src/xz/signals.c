int user_abort = 0;
void signals_init(void) { return; }
void signals_block(void) { return; }
void signals_unblock(void) { return; }
void signals_exit(void) { return; }
